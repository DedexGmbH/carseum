# Carseum Dash vent clip

This holds the round Dash case (`../carseum-dash-bezel.stl` + `../carseum-dash-back.stl`) on a car's air vent, like a phone vent holder:
- No measuring and no tools.
- It comes off without a trace.
- The screen is angled **10° towards the driver**.

It was made for testing in a **BMW F10 (left-hand drive)**. It works in most cars with **horizontal vent slats**.

## Files
| File | What | Print |
|---|---|---|
| `vent-clip-cup.stl` | Cup the Dash case clicks into, angled for **left-hand drive** (Germany) | Flat on its back, no supports |
| `vent-clip-uk-cup.stl` | The same cup angled for **right-hand drive** (UK, your E93) | Flat on its back, no supports |
| `vent-clip-clip.stl` | Clip that grips one vent slat | **Lying on its side** (the big flat side down), no supports |
| `vent-clip.scad` | The model: angle, slat gap and fit are at the top | |

You also need the round Dash case: `../carseum-dash-bezel.stl` and `../carseum-dash-back.stl`.

## Print settings
| | |
|---|---|
| Material | **PETG**, black. Fine for a test; it handles a warm car. ASA is even better for summer. |
| Layer height | 0.2 mm |
| Walls | 4 (keeps the clip arms springy and strong) |
| Infill | 40% |
| Supports | **None** |

All four parts together take about 1.5–2 hours and about 25 g of filament.

## Assembly
1. Put the Dash board in the round case and snap the back on.
2. **Slide the clip's dovetail sideways into the slot** on the back of the cup. It's a snug fit; add a drop of glue if it's loose.
3. **Push the Dash case into the cup** until it clicks, with the **USB cable coming out of the notch at the bottom**.
4. Push the clip's arms **onto one vent slat**, straight in, until the slat sits deep between the arms. The lower arm springs open and grips it.
5. Turn the vent slat a little to aim the screen at your eyes.
6. Run the USB cable down to the car's USB port or 12 V adapter.

**If it's loose on the slat:** in `vent-clip.scad`, set `slat_gap` smaller (for example 1.5) and reprint just the clip, a 10-minute print. **If it's too tight**, make it bigger (2.2).

## Where to get it printed in Cologne or Germany
- **Stadtbibliothek Köln (central library, Neumarkt)** has a MakerSpace with 3D printers. Ask about printing times and whether they print in PETG.
- **Hackspaces / FabLabs** in Cologne are usually happy to help for a small donation.
- **Online:** Craftcloud, JLC3DP, or a "3D-Druck Service" on eBay/Etsy. Say: "PETG, black, 0.2 mm, 4 walls, 40% infill, no supports."

## Safety
- Don't put it where it blocks your view of the road, the airbag areas or the hazard button.
- Make sure it can't fall into the footwell. Check it grips firmly before you drive.
- Don't touch the Dash while driving; it changes by itself.
